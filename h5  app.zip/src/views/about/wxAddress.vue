<template>
        <div>
            微信地址页面
        </div>
</template>

<script>
export default {
    
}
</script>

<style lang="less" scoped>

</style>