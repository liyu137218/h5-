<template>
  <div class="course">
    <h2>  赚佣教程  这是index.vue页面 </h2>
  </div>
</template>

<script>
export default {
  name: 'course',

  data () {
    return {
    }
  },

  methods: {}
}
</script>

<style lang='less' scoped>

</style>
