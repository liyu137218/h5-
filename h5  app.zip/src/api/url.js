export default {
    // 本地
    // imgUrl: 'http://192.168.1.12:8080',
    // apiUrl: 'http://192.168.1.12:8080/wx',
    // 本地
    // imgUrl: 'http://192.168.1.11:8082',
    // apiUrl: 'http://192.168.1.11:8082/wx'
    // 线上
    // imgUrl: 'https://www.xxxkeji.com:8080',
    // apiUrl: 'https://www.xxxkeji.com:8080/wx'
    // 线上
    imgUrl: 'http://121.36.24.14:8081',
    apiUrl: 'http://121.36.24.14:8081/api'
}